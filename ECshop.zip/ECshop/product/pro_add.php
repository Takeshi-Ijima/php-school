<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>商品追加</title>
    </head>
    <body>
        <h1>商品追加</h1>
        <form method="post" action="pro_add_check.php" enctype="multipart/form-data">
            <p>商品名を入力してください <input type="text" name="name" value=""></p>
            <p>商品価格を入力してください <input type="text" name="price"></p>
            <p>画像を選んでください <input type="file" name="image" value=""></p>
            <input type="button" onclick="histro.back()" name="" value="戻る">
            <input type="submit" value="OK">
        </form>
    </body>
</html>
