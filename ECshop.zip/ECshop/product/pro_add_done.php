<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>商品の追加完了</title>
    </head>
    <body>
        <?php
            try{
                require_once('../common/common.php');
                $post = sanitize($_POST);

                $pro_name = $post['name'];
                $pro_price = $post['price'];
                $pro_image_name = $post['image_name'];

                $dsn = "mysql:dbname=ECshop;host=localhost;charset=utf8";
                $user = "root";
                $password = "root";
                $dbh = new PDO($dsn, $user, $password);
                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = "insert into EC_product (name, price, image) value(?, ?, ?)";
                $stmt = $dbh->prepare($sql);
                $data[] = $pro_name;
                $data[] = $pro_price;
                $data[] = $pro_image_name;
                $stmt->execute($data);

                $dbh = null;

                print "{$pro_name}を追加しました。";
            }catch(Exception $e){
                die("エラー:" . $e->getMessage());
            }
         ?>
        <p><a href="pro_list.php">戻る</p>
    </body>
</html>
