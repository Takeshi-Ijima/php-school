<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>管理者-商品詳細</title>
        <link rel="stylesheet" href="../css/style.css">
        <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    </head>
    <body>
        <header>
            <h1>管理者-商品詳細</h1>
        </header>
        <?php
            try{
                $pro_code = $_GET['procode'];
                $dsn = 'mysql:dbname=ECshop;host=localhost;charset=utf8';
                $user = 'root';
                $password = 'root';
                $dbh = new PDO($dsn, $user, $password);
                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $sql = 'select name, price, image from EC_product where code = ?';
                $stmt = $dbh->prepare($sql);
                $data[] = $pro_code;
                $stmt->execute($data);

                $rec = $stmt->fetch(PDO::FETCH_ASSOC);
                $pro_name = $rec['name'];
                $pro_price = $rec['price'];
                $pro_image_name = $rec['image'];

                $dbh = null;

                if($pro_image_name == ""){
                    $disp_image = '';
                }else{
                    $disp_image = '<img src="./image/'.$pro_image_name.'">';
                }

            }catch(Exception $e){
                die($e->getMessage());
            }
         ?>
        <div class="disp_name">
            <p>商品名：<?php print $pro_name; ?></p>
        </div>
        <div class="disp_price">
            <p>価格：<?php print $pro_price; ?>円</p>
        </div>
        <div class="disp_img">
            <?php print $disp_image; ?>
        </div>
        <form class="pro_list_back">
            <input type="button" onclick="history.back()" value="戻る">
        </form>
    </body>
</html>
