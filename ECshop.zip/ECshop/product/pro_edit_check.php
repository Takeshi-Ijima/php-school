<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>商品追加確認ページ</title>
    </head>
    <body>
        <?php
            require_once('../common/common.php');
            $post = sanitize($_POST);

            $pro_code = $post['code'];
            $pro_name = $post['name'];
            $pro_price = $post['price'];
            $pro_image_name_old = $post['image_name_old'];
            $pro_image = $_FILES['image'];

            if($pro_name === ''){
                print "商品名が入力されていません";
            }else{
                print '商品名：' . $pro_name;
            }

            if($pro_image['size'] > 0){
                if($pro_image['size'] > 1000000){
                    print '画像が大きすぎます。';
                }else{
                    move_uploaded_file($pro_image['tmp_name'], './image/' . $pro_image['name']);
            		print '<img src="./image/'.$pro_image['name'].'">';
                }
            }


            if(preg_match('/\A[0-9]+\z/', $pro_price) === 0 || $pro_image['size'] > 1000000){
                print '半角英数字で入力してください';
            }else{
                print '価格：'. $pro_price . '円';
            }

            if($pro_name === "" || preg_match('/\A[0-9]+\z/', $pro_price) === 0){
                print '<form>';
                print '<input type="button" onclick="history.back()" value="戻る">';
                print '</form>';
            }else{
                print '上記のように変更します';
                print '<form method="post" action="pro_edit_done.php">';
                print '<input type="hidden" name="code" value="'.$pro_code.'">';
                print '<input type="hidden" name="name" value="'.$pro_name.'">';
                print '<input type="hidden" name="price" value="'.$pro_price.'">';
                print '<input type="hidden" name="image_name_old" value="'.$pro_image_name_old.'">';
                print '<input type="hidden" name="image_name" value="'.$pro_image['name'].'">';
                print '<input type="button" onclick="history.back()" value="戻る">';
                print '<input type="submit" value="OK">';
                print '</form>';
            }
         ?>
    </body>
</html>
