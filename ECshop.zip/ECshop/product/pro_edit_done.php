<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>商品の修正完了</title>
    </head>
    <body>
        <?php
            try{
                require_once('../common/common.php');
                $post = sanitize($_POST);

                $pro_code = $post['code'];
                $pro_name = $post['name'];
                $pro_price = $post['price'];
                $pro_image_name_old = $post['image_name_old'];
                $pro_image_name = $post['image_name'];

                $dsn = "mysql:dbname=ECshop;host=localhost;charset=utf8";
                $user = "root";
                $password = "root";
                $dbh = new PDO($dsn, $user, $password);
                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = " UPDATE EC_product SET name = ?, price = ?, image = ? WHERE code = ?";
                $stmt = $dbh->prepare($sql);

                $data[] = $pro_name;
                $data[] = $pro_price;
                $data[] = $pro_image_name;
                $data[] = $pro_code;
                $stmt->execute($data);

                if($pro_image_name_old !== $pro_image_name){
                    unlink('./image/'.$pro_image_name_old);
                }

                $dbh = null;

                print "{$pro_name}に修正しました。";
            }catch(Exception $e){
                die("エラー:" . $e->getMessage());
            }
         ?>
        <p><a href="pro_list.php">戻る</p>
    </body>
</html>
