<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>管理者-商品一覧</title>
        <link rel="stylesheet" href="../css/style.css">
        <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    </head>
    <body>
        <div class="product_list">
            <h1>管理者-商品一覧</h1>
            <p><a href="../staff_login/staff_top.php">トップメニュー</a></p>
        </div>
        <?php
            try{
                $dsn = 'mysql:dbname=ECshop;host=localhost;charset=utf8';
                $user = 'root';
                $password = "root";
                $dbh = new PDO($dsn, $user, $password);
                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $sql = "select code, name, price from EC_product where 1";
                $stmt = $dbh->prepare($sql);
                $stmt->execute();

                $dbh = null;

                print '<form method="post" action="pro_branch.php">';
                    while(true){
                        $rec = $stmt->fetch(PDO::FETCH_ASSOC);
                        if($rec === false){
                            break;
                        }
                        print '<div class="product_list_box"><label><input type="radio" name="procode" value="'.$rec['code'].'">';
                        print " {$rec['name']}";
                        print " --- {$rec['price']}円</label></div>";
                    }
                print '<div class="wrap_shop_btn">';
                print '<input type="submit" name="disp" value="参照" class="shop_btn">';
                print '<input type="submit" name="add" value="追加" class="shop_btn">';
                print '<input type="submit" name="edit" value="修正" class="shop_btn">';
                print '<input type="submit" name="delete" value="削除" class="shop_btn">';
                print '</div>';
                print '</form>';
            }catch(Exception $e){
                die($e->getMessage());
            }

         ?>
    </body>
</html>
