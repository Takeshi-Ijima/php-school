<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>商品を選択してください</title>
    </head>
    <body>
        <h1>商品を選択してください</h1>
        <a href="pro_list.php">一覧へ戻る</a>
    </body>
</html>
