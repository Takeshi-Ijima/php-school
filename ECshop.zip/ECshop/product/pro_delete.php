<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>商品削除</title>
    </head>
    <body>
        <h1>商品の削除</h1>
        <?php
            try{
                $pro_code = $_GET['procode'];
                $dsn = 'mysql:dbname=ECshop;host=localhost;charset=utf8';
                $user = 'root';
                $password = 'root';
                $dbh = new PDO($dsn, $user, $password);
                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $sql = 'select name, image from EC_product where code = ?';
                $stmt = $dbh->prepare($sql);
                $data[] = $pro_code;
                $stmt->execute($data);

                $rec = $stmt->fetch(PDO::FETCH_ASSOC);
                $pro_name = $rec['name'];
                $pro_image_name = $rec['image'];

                $dbh = null;

                if($pro_image_name === ""){
                    $disp_image = "";
                }else{
                    $disp_image = '<img src="./image/'.$pro_image_name.'">';
                }

            }catch(Exception $e){
                die($e->getMessage());
            }
         ?>
        <p>商品コード</p>
        <h3><?php print $pro_code; ?></h3>
        <p>商品名</p>
        <h3><?php print $pro_name; ?></h3>
        <?php print $disp_image; ?>
        <p><strong>以上の商品を削除しますがよろしいですか？</strong></p>
        <form class="" action="pro_delete_done.php" method="post">
            <input type="hidden" name="code" value="<?php print $pro_code;?>">
            <input type="hidden" name="image_name" value="<?php print $pro_image_name; ?>">
            <input type="button" onclick="history.back()" value="戻る">
            <input type="submit" value="OK">
        </form>
    </body>
</html>
