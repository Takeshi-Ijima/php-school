<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>商品修正</title>
    </head>
    <body>
        <h1>商品修正</h1>
        <?php
            try{
                $pro_code = $_GET['procode'];
                $dsn = 'mysql:dbname=ECshop;host=localhost;charset=utf8';
                $user = 'root';
                $password = 'root';
                $dbh = new PDO($dsn, $user, $password);
                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $sql = 'select name, price, image from EC_product where code = ?';
                $stmt = $dbh->prepare($sql);
                $data[] = $pro_code;
                $stmt->execute($data);

                $rec = $stmt->fetch(PDO::FETCH_ASSOC);
                $pro_name = $rec['name'];
                $pro_price = $rec['price'];
                $pro_image_name_old = $rec['image'];

                $dbh = null;

                if($pro_image_name_old === ""){
                    $disp_image = "";
                }else{
                    $disp_image = '<img src="./image/'.$pro_image_name_old.'">';
                }

            }catch(Exception $e){
                die($e->getMessage());
            }
         ?>
        <p><?php print $pro_code; ?></p>
        <form class="" action="pro_edit_check.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="code" value="<?php print $pro_code;?>">
            <input type="hidden" name="image_name_old" value="<?php print $pro_image_name_old; ?>">
            <p>商品名 <input type="text" name="name" value="<?php print $pro_name; ?>"></p>
            <p>商品価格 <input type="text" name="price" value="<?php print $pro_price; ?>">円</p>
            <?php print $disp_image; ?>
            <p>画像を選択してください</p>
            <input type="file" name="image">
            <input type="button" onclick="history.back()" value="戻る">
            <input type="submit" value="OK">
        </form>
    </body>
</html>
