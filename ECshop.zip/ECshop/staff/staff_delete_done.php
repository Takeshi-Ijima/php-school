<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>スタッフの削除完了</title>
    </head>
    <body>
        <?php
            try{
                $staff_code = $_POST['code'];

                $dsn = "mysql:dbname=ECshop;host=localhost;charset=utf8";
                $user = "root";
                $password = "root";
                $dbh = new PDO($dsn, $user, $password);
                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = "delete from EC_staff where code = ?";
                $stmt = $dbh->prepare($sql);
                $data[] = $staff_code;
                $stmt->execute($data);

                $dbh = null;
            }catch(Exception $e){
                die("エラー:" . $e->getMessage());
            }
         ?>
        <p>削除しました。</p>
        <p><a href="staff_list.php">戻る</p>
    </body>
</html>
