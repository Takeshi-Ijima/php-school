<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>スタッフ修正</title>
    </head>
    <body>
        <h1>スタッフ修正</h1>
        <?php
            try{
                $staff_code = $_GET['staffcode'];
                $dsn = 'mysql:dbname=ECshop;host=localhost;charset=utf8';
                $user = 'root';
                $password = 'root';
                $dbh = new PDO($dsn, $user, $password);
                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $sql = 'select name from EC_staff where code = ?';
                $stmt = $dbh->prepare($sql);
                $data[] = $staff_code;
                $stmt->execute($data);

                $rec = $stmt->fetch(PDO::FETCH_ASSOC);
                $staff_name = $rec['name'];

                $dbh = null;

            }catch(Exception $e){
                die($e->getMessage());
            }
         ?>
        <p><?php print $staff_code; ?></p>
        <form class="" action="staff_edit_check.php" method="post">
            <input type="hidden" name="code" value="<?php print $staff_code;?>">
            <p>スタッフ名</p>
            <input type="text" name="name" value="<?php print $staff_name;?>">
            <p>パスワード</p>
            <input type="text" name="pass_1" value="">
            <p>確認パスワード</p>
            <input type="text" name="pass_2" value="">
            <input type="button" onclick="history.back()" value="戻る">
            <input type="submit" value="OK">
        </form>
    </body>
</html>
