<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>スタッフ追加</title>
    </head>
    <body>
        <h1>スタッフ追加</h1>
        <form method="post" action="staff_add_check.php">
            <p>スタッフ名を入力してください<input type="text" name="name" value=""></p>
            <p>パスワードを入力してください<input type="text" name="pass_1" value=""></p>
            <p>パスワードをもう一度入力してください<input type="text" name="pass_2" value=""></p>
            <input type="button" onclick="histro.back()" name="" value="戻る">
            <input type="submit" value="OK">
        </form>
    </body>
</html>
