<?php
    session_start();
    session_regenerate_id(true);
    if(isset($_SESSION['login']) === false){
        print '<link rel="stylesheet" href="../css/style.css">';
        print '<div class="staff_top_err">';
        print '<p>ログインされていません</p>';
        print '<p><a href="../staff_login/index.php">ログイン画面へ</a></p>';
        print '</div>';
        exit();
    }else{
        print '<div class="header_user">';
        print $_SESSION['staff_name'];
        print 'さん ログイン中';
        print '</div>';
    }
?>
<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>スタッフ一覧</title>
        <link rel="stylesheet" href="../css/style.css">
        <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    </head>
    <body>
        <header>
            <h1>スタッフ一覧</h1>
        </header>
        <div class="">
            <a href="../staff_login/staff_top.php">トップメニュー</a>
        </div>
        <?php
            try{
                $dsn = 'mysql:dbname=ECshop;host=localhost;charset=utf8';
                $user = 'root';
                $password = "root";
                $dbh = new PDO($dsn, $user, $password);
                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $sql = "select code, name from EC_staff where 1";
                $stmt = $dbh->prepare($sql);
                $stmt->execute();

                $dbh = null;

                print '<form method="post" action="staff_branch.php">';
                    while(true){
                        $rec = $stmt->fetch(PDO::FETCH_ASSOC);
                        if($rec === false){
                            break;
                        }
                        print '<div class="staff_list">';
                        print '<p><label><input type="radio" name="staffcode" value="'.$rec['code'].'">';
                        print " {$rec['name']}</label></p>";
                        print '</div>';
                    }
                print '<div class="wrap_staff_list_btn">';
                print '<input type="submit" name="disp" value="参照">';
                print '<input type="submit" name="add" value="追加">';
                print '<input type="submit" name="edit" value="修正">';
                print '<input type="submit" name="delete" value="削除">';
                print '</div>';
                print '</form>';
            }catch(Exception $e){
                die($e->getMessage());
            }

         ?>
    </body>
</html>
