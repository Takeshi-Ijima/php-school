<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>スタッフを選択してください</title>
    </head>
    <body>
        <h1>スタッフを選択してください</h1>
        <a href="staff_list.php">一覧へ戻る</a>
    </body>
</html>
