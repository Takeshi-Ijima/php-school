<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>スタッフ追加確認ページ</title>
    </head>
    <body>
        <?php
            require_once('../common/common.php');
            $post = sanitize($_POST);

            $staff_name = $post['name'];
            $staff_pass_1 = $post['pass_1'];
            $staff_pass_2 = $post['pass_2'];

            $staff_pass_1 = md5($staff_pass_1);
            $staff_pass_2 = md5($staff_pass_2);

            if($staff_name === ''){
                print "スタッフ名が入力されていません";
            }else{
                print "スタッフ名 $staff_name ";
            }

            if($staff_pass_1 === ""){
                print "パスワードが入力されていません。";
            }

            if($staff_pass_1 !== $staff_pass_2){
                print "パスワードが一致しません。";
            }

            if($staff_name === "" || $staff_pass_1 === "" || $staff_pass_2 === ""){
                print '<form>';
                print '<input type="button" onclick="history.back()" value="戻る">';
                print '</form>';
            }else{
                $staff_pass = md5($staff_pass_1);
                print '<form method="post" action="staff_add_done.php">';
                print '<input type="hidden" name="name" value="'.$staff_name.'">';
                print '<input type="hidden" name="pass" value="'.$staff_pass_1.'">';
                print '<input type="button" onclick="history.back()" value="戻る">';
                print '<input type="submit" value="OK">';
                print '</form>';
            }
         ?>
    </body>
</html>
