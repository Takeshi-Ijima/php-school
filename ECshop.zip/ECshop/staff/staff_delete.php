<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>スタッフ削除</title>
    </head>
    <body>
        <h1>スタッフの削除</h1>
        <?php
            try{
                $staff_code = $_GET['staffcode'];
                $dsn = 'mysql:dbname=ECshop;host=localhost;charset=utf8';
                $user = 'root';
                $password = 'root';
                $dbh = new PDO($dsn, $user, $password);
                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $sql = 'select name from EC_staff where code = ?';
                $stmt = $dbh->prepare($sql);
                $data[] = $staff_code;
                $stmt->execute($data);

                $rec = $stmt->fetch(PDO::FETCH_ASSOC);
                $staff_name = $rec['name'];

                $dbh = null;

            }catch(Exception $e){
                die($e->getMessage());
            }
         ?>
        <p>スタッフコード</p>
        <h3><?php print $staff_code; ?></h3>
        <p>スタッフ名</p>
        <h3><?php print $staff_name; ?></h3>
        <p><strong>以上のスタッフを削除しますがよろしいですか？</strong></p>
        <form class="" action="staff_delete_done.php" method="post">
            <input type="hidden" name="code" value="<?php print $staff_code;?>">
            <input type="button" onclick="history.back()" value="戻る">
            <input type="submit" value="OK">
        </form>
    </body>
</html>
