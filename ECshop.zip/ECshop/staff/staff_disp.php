<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>スタッフ修正</title>
    </head>
    <body>
        <h1>スタッフ修正</h1>
        <?php
            try{
                $staff_code = $_GET['staffcode'];
                $dsn = 'mysql:dbname=ECshop;host=localhost;charset=utf8';
                $user = 'root';
                $password = 'root';
                $dbh = new PDO($dsn, $user, $password);
                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $sql = 'select name from EC_staff where code = ?';
                $stmt = $dbh->prepare($sql);
                $data[] = $staff_code;
                $stmt->execute($data);

                $rec = $stmt->fetch(PDO::FETCH_ASSOC);
                $staff_name = $rec['name'];

                $dbh = null;

            }catch(Exception $e){
                die($e->getMessage());
            }
         ?>
        <p>スタッフコード：<?php print $staff_code; ?></p>
        <p>スタッフ名：<?php print $staff_name; ?></p>
        <form>
            <input type="button" onclick="history.back()" value="戻る">
        </form>
    </body>
</html>
