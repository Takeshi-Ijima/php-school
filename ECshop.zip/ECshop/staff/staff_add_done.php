<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>スタッフの追加完了</title>
    </head>
    <body>
        <?php
            try{
                require_once('../common/common.php');
                $post = sanitize($_POST);

                $staff_name = $post['name'];
                $staff_pass = $post['pass'];

                $dsn = "mysql:dbname=ECshop;host=localhost;charset=utf8";
                $user = "root";
                $password = "root";
                $dbh = new PDO($dsn, $user, $password);
                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $sql = "insert into EC_staff (name, password) value(?, ?)";
                $stmt = $dbh->prepare($sql);
                $data[] = $staff_name;
                $data[] = $staff_pass;
                $stmt->execute($data);

                $dbh = null;

                print "{$staff_name}さんを追加しました。";
            }catch(Exception $e){
                die("エラー:" . $e->getMessage());
            }
         ?>
        <p><a href="staff_list.php">戻る</p>
    </body>
</html>
