<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>スタッフログイン</title>
        <link rel="stylesheet" href="../css/style.css">
        <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    </head>
    <body>
        <div class="wrap_loginform">
            <h1>スタッフログイン</h1>
            <form class="" action="staff_login_check.php" method="post">
                <p><i class="fas fa-user"></i> スタッフコード</p>
                <p><input type="text" name="code" value=""></p>
                <p><i class="fas fa-unlock-alt"></i> パスワード</p>
                <p><input type="password" name="pass" value=""></p>
                <p><input type="submit" name="" value="ログイン" class="login_btn"></p>
            </form>
        </div>
    </body>
</html>
