<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>ログインエラー</title>
        <link rel="stylesheet" href="../css/style.css">
        <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    </head>
    <body>
        <?php
            try{
                require_once('../common/common.php');
                $post = sanitize($_POST);

                $staff_code = $post['code'];
                $staff_pass = $post['pass'];

                $staff_pass = md5($staff_pass);

                $dsn = "mysql:dbname=ECshop;host=localhost;charset=utf8";
                $user = "root";
                $password = "root";
                $dbh = new PDO($dsn, $user, $password);
                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $sql = "select name from EC_staff where code = ? AND password = ?";
                $stmt = $dbh->prepare($sql);
                $data[] = $staff_code;
                $data[] = $staff_pass;
                $stmt->execute($data);

                $dbh = null;

                $rec = $stmt->fetch(PDO::FETCH_ASSOC);
                if($rec == false){
                    print '<div class="login_err">';
                    print '<p>スタッフコードかパスワードが間違っています。</p>';
                    print '<div class="back_box"><a href="index.php">戻る</a></div>';
                    print '</div>';
                }else{
                    session_start();
                    $_SESSION['login'] = 1;
                    $_SESSION['staff_code'] = $staff_code;
                    $_SESSION['staff_name'] = $rec['name'];
                    header('Location: staff_top.php');
                    exit();
                }
            }catch(Exception $e){
                die($e->getMessage());
            }
         ?>
    </body>
</html>
