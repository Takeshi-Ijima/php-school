<?php
    session_start();
    $_SESSION = array();
    if(isset($_COOKIE[session_name()]) === true){
        setcookie(session_name(), '', time()-42000, '/');
    }
    session_destroy();
 ?>
<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>ログアウトしました</title>
    </head>
    <body>
        <h1>ログアウトしました。</h1>
        <p><a href="../staff_login/index.php">ログイン画面へ</a></p>
    </body>
</html>
