<?php
    session_start();
    session_regenerate_id(true);
    if(isset($_SESSION['login']) === false){
        print '<link rel="stylesheet" href="../css/style.css">';
        print '<div class="staff_top_err">';
        print '<p>ログインされていません</p>';
        print '<p><a href="../staff_login/index.php">ログイン画面へ</a></p>';
        print '</div>';
        exit();
    }else{
        print '<div class="header_user">';
        print $_SESSION['staff_name'];
        print 'さん ログイン中';
        print '</div>';
    }
?>
<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>管理トップ</title>
        <link rel="stylesheet" href="../css/style.css">
        <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    </head>
    <body>
        <header>
            <h1>ECshop 管理者ページ</h1>
        </header>
        <div class="wrap_box">
            <div class="wrap_icon_box">
                <i class="fas fa-users"></i>
            </div>
            <div class="wrap_btn_box">
                <a href="../staff/staff_list.php">スタッフ管理</a>
            </div>
        </div>
        <div class="wrap_box">
            <div class="wrap_icon_box">
                <i class="fas fa-shopping-cart"></i>
            </div>
            <div class="wrap_btn_box">
                <a href="../product/pro_list.php">商品管理</a>
            </div>
        </div>
        <div class="wrap_box">
            <div class="wrap_icon_box">
                <i class="fas fa-unlock-alt"></i>
            </div>
            <div class="wrap_btn_box">
                <a href="staff_logout.php">ログアウト</a>
            </div>
        </div>
    </body>
</html>
