<?php
    session_start();
    session_regenerate_id(true);

    if(isset($_SESSION['member_login'])==false){
    	print 'ようこそゲスト様';
    	print '<a href="member_login.html">会員ログイン</a><br />';
    	print '<br />';
    }else{
    	print 'ようこそ';
    	print $_SESSION['member_name'];
    	print '様';
    	print '<a href="member_logout.php">ログアウト</a><br />';
    	print '<br />';
    }
?>
<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>カート</title>
    </head>
    <body>
        <?php
            try{
                $pro_code = $_GET['procode'];

                if(isset($_SESSION['cart']) === true){
                    $cart = $_SESSION['cart'];
                    $count = $_SESSION['count'];

                    if(in_array($pro_code, $cart) === true){
                        print '<p>その商品はすでにカートに入っています。</p>';
                        print '<a href="shop_list.php">商品一覧に戻る</a>';
                        exit();
                    }
                }

                $cart[] = $pro_code;
                $count[] = 1;
                $_SESSION['cart'] = $cart;
                $_SESSION['count'] = $count;

            }catch(Exception $e){
                die($e->getMessage());
            }
         ?>
        <p>カートに追加されました。</p>
        <p><a href="shop_list.php">商品一覧へ</a></p>
    </body>
</html>
