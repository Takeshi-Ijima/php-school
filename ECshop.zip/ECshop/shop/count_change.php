<?php
    session_start();
    session_regenerate_id(true);

    require_once('../common/common.php');

    $post=sanitize($_POST);

    $max = $post['max'];
    for($i=0;$i<$max;$i++){
        if(preg_match("/\A[0-9]+\z/", $post['count'.$i]) === 0){
            print '<p>数量に誤りがあります</p>';
            print '<a href="shop_list.php">カートに戻る</a>';
            exit();
        }

        if($post['count'.$i] < 1 || 10 < $post['count'.$i]){
            print '数量必ず1個以上10個までです。';
            print '<a href="shop_cartlook.php">カートに戻る</a>';
            exit();
        }
        $count[]=$post['count'.$i];
    }

    $cart = $_SESSION['cart'];

    for($i = $max; 0 <= $i; $i--){
        if(isset($_POST['delete'.$i]) === true){
            array_splice($cart, $i, 1);
            array_splice($count, $i, 1);
        }
    }
    $_SESSION['cart'] = $cart;
    $_SESSION['count'] = $count;

    header('Location:shop_cartlook.php');
 ?>
