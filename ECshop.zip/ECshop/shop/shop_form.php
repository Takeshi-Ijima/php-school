<!DOCTYPE html>
<html lang="en" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>購入フォーム</title>
    </head>
    <body>
        <h1>お客様情報を入力してください</h1>
        <form class="" action="shop_form_check.php" method="post">
            <p>お名前</p>
            <input type="text" name="onamae" value="">
            <p>メールアドレス</p>
            <input type="text" name="email" value="">
            <p>郵便番号</p>
            <input type="text" name="postal1" value=""> - <input type="text" name="postal2" value="">
            <p>住所</p>
            <input type="text" name="address" value="">
            <p>電話番号</p>
            <input type="text" name="tel" value="">
            <input type="radio" name="chumon" value="chumonkonkai" checked>今回だけの注文<br />
            <input type="radio" name="chumon" value="chumontouroku">会員登録しての注文<br />
            <br />
            ※会員登録する方は以下の項目も入力してください。<br />
            パスワードを入力してください。<br />
            <input type="password" name="pass" style="width:100px"><br />
            パスワードをもう１度入力してください。<br />
            <input type="password" name="pass2" style="width:100px"><br />
            性別<br />
            <input type="radio" name="danjo" value="dan" checked>男性<br />
            <input type="radio" name="danjo" value="jo">女性<br />
            生まれ年<br />
            <select name="birth">
            <option value="1910">1910年代</option>
            <option value="1920">1920年代</option>
            <option value="1930">1930年代</option>
            <option value="1940">1940年代</option>
            <option value="1950">1950年代</option>
            <option value="1960">1960年代</option>
            <option value="1970">1970年代</option>
            <option value="1980" selected>1980年代</option>
            <option value="1990">1990年代</option>
            <option value="2000">2000年代</option>
            <option value="2010">2010年代</option>
            </select>
            <input type="button" onclick="history.back()" value="戻る">
            <input type="submit" value="OK">
        </form>
    </body>
</html>
