<?php
    session_start();
    session_regenerate_id(true);

    if(isset($_SESSION['member_login'])==false){
    	print 'ようこそゲスト様';
    	print '<a href="member_login.html">会員ログイン</a><br />';
    	print '<br />';
    }else{
    	print 'ようこそ';
    	print $_SESSION['member_name'];
    	print '様';
    	print '<a href="member_logout.php">ログアウト</a><br />';
    	print '<br />';
    }
?>
<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>カート一覧</title>
    </head>
    <body>
        <h1>カート一覧</h1>
        <?php
            try{
                if(isset($_SESSION['cart']) === true){
                    $cart = $_SESSION['cart'];
                    $count = $_SESSION['count'];
                    $max = count($cart);
                }else{
                    $max = 0;
                }
                // print '<pre>';
                // var_dump($cart);
                // print '</pre>';
                // exit();
                // var_dump($count);

                if($max === 0){
                    print '<p>カートの中身が空です。</p>';
                    print '<a href="shop_list.php">商品一覧へ</a>';
                    exit();
                }

                $dsn = 'mysql:dbname=ECshop;host=localhost;charset=utf8';
                $user = 'root';
                $password = 'root';
                $dbh = new PDO($dsn, $user, $password);
                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                foreach($cart as $key => $val){
                    $sql = 'select code, name, price, image from EC_product where code = ?';
                    $stmt = $dbh->prepare($sql);
                    $data[0] = $val;
                    $stmt->execute($data);

                    $rec = $stmt->fetch(PDO::FETCH_ASSOC);

                    $pro_name[] = $rec['name'];
                    $pro_price[] = $rec['price'];
                    if($rec['image'] === ""){
                        $pro_image[] = '';
                    }else{
                        $pro_image[] = '<img src="../product/image/'.$rec['image'].'">';
                    }
                }

                $dbh = null;

            }catch(Exception $e){
                die($e->getMessage());
            }
         ?>
        <form method="post" action="count_change.php">
            <?php
                for($i = 0; $i < $max; $i++){
            ?>
                <p>商品名：<?php print $pro_name[$i]; ?></p>
                <?php print $pro_image[$i]; ?>
                <p>価格 : <?php print $pro_price[$i]; ?>円</p>
                <input type="text" name="count<?php print $i; ?>" value="<?php print $count[$i]; ?>">
                <p>合計 : <?php print $pro_price[$i] * $count[$i]; ?>円</p>
                <p>削除 : <input type="checkbox" name="delete<?php print $i;?>"></p>
            <?php
                }
            ?>
            <input type="hidden" name="max" value="<?php print $max; ?>">
            <input type="submit" value="数量変更">
            <input type="button" onclick="history.back()" value="戻る">
        </form>
        <a href="shop_form.php">ご購入手続きへ進む</a>

        <?php
        	if(isset($_SESSION["member_login"])==true)
        	{
        		print '<a href="shop_kantan_check.php">会員かんたん注文へ進む</a><br />';
        	}
        ?>
    </body>
</html>
