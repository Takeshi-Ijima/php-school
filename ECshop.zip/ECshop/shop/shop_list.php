<?php
    session_start();
    session_regenerate_id(true);

    if(isset($_SESSION['member_login'])==false){
        print '<div class="wrap_user_guest">';
        print 'ようこそゲスト様';
        print '<a href="member_login.php">会員ログイン</a><br />';
        print '</div>';
    }else{
        print '<div class="wrap_user_guest">';
        print $_SESSION['member_name'];
        print ' 様';
        print '<a href="member_logout.php">ログアウト</a><br />';
        print '</div>';
    }
?>
<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>商品一覧</title>
        <link rel="stylesheet" href="../css/shop_list.css">
        <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">
    </head>
    <body>
        <header>
            <h1>商品一覧</h1>
        </header>
        <?php
            try{
                $dsn = 'mysql:dbname=ECshop;host=localhost;charset=utf8';
                $user = 'root';
                $password = "root";
                $dbh = new PDO($dsn, $user, $password);
                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $sql = "select code, name, price from EC_product where 1";
                $stmt = $dbh->prepare($sql);
                $stmt->execute();

                $dbh = null;

                while(true){
                    $rec = $stmt->fetch(PDO::FETCH_ASSOC);
                    if($rec === false){
                        break;
                    }
                    print '<div class="shop_list">';
                    print '<p><a href="shop_product.php?procode='.$rec['code'].'"><i class="fas fa-shopping-basket"></i> ';
                    print "{$rec['name']}";
                    print " --- {$rec['price']}円</a></p>";
                    print '</div>';
                }
            }catch(Exception $e){
                die($e->getMessage());
            }
         ?>
        <p><a href="shop_cartlook.php">カートを見る</a></p>
    </body>
</html>
