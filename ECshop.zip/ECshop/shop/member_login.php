<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title></title>
    </head>
    <body>
        会員ログイン
        <form method="post" action="member_login_check.php">
            登録メールアドレス
            <input type="text" name="email" ><br />
            パスワード
            <input type="password" name="pass"><br />
            <input type="submit" value="ログイン">
        </form>
    </body>
</html>
