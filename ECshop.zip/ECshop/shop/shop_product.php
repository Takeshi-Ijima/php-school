<?php
    session_start();
    session_regenerate_id(true);

    if(isset($_SESSION['member_login'])==false){
    	print 'ようこそゲスト様';
    	print '<a href="member_login.html">会員ログイン</a><br />';
    	print '<br />';
    }else{
    	print 'ようこそ';
    	print $_SESSION['member_name'];
    	print '様';
    	print '<a href="member_logout.php">ログアウト</a><br />';
    	print '<br />';
    }
?>
<!DOCTYPE html>
<html lang="ja" dir="ltr">
    <head>
        <meta charset="utf-8">
        <title>商品詳細</title>
    </head>
    <body>
        <h1>商品詳細</h1>
        <?php
            try{
                $pro_code = $_GET['procode'];
                $dsn = 'mysql:dbname=ECshop;host=localhost;charset=utf8';
                $user = 'root';
                $password = 'root';
                $dbh = new PDO($dsn, $user, $password);
                $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                $sql = 'select name, price, image from EC_product where code = ?';
                $stmt = $dbh->prepare($sql);
                $data[] = $pro_code;
                $stmt->execute($data);

                $rec = $stmt->fetch(PDO::FETCH_ASSOC);
                $pro_name = $rec['name'];
                $pro_price = $rec['price'];
                $pro_image_name = $rec['image'];

                $dbh = null;

                if($pro_image_name == ""){
                    $disp_image = '';
                }else{
                    $disp_image = '<img src="../product/image/'.$pro_image_name.'">';
                }
                print '<a href="shop_cartin.php?procode='.$pro_code.'">カートに入れる</a>';
            }catch(Exception $e){
                die($e->getMessage());
            }
         ?>
        <p>商品コード：<?php print $pro_code; ?></p>
        <p>商品名：<?php print $pro_name; ?></p>
        <p>価格 : <?php print $pro_price; ?>円</p>
        <?php print $disp_image; ?>
        <form>
            <input type="button" onclick="history.back()" value="戻る">
        </form>
    </body>
</html>
