<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>トップページ</title>
    </head>
    <body>
        <p><a href="./staff_login/index.php">会員ログインページ</a></p>
        <p><a href="./shop/shop_list.php">ショッピングページ</a></p>
    </body>
</html>
